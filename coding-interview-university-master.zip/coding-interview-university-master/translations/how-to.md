Please put new translation README files here.

I'll migrate the existing translations when they are ready.

To start a new translation, please:

1. Make an issue (for collaboration with other translators)
2. Make a pull request to collaborate and commit to.
3. Let me know when it's ready to pull.

Thank you!
